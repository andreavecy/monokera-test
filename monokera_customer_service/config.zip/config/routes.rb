Rails.application.routes.draw do
  resources :customers
end
