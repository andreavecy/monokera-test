# spec/integration/order_creation_spec.rb
require 'rails_helper'
require 'json'

RSpec.describe 'Order creation integration', type: :request do
  let(:customer_id) { 1 }

  before do
    customer
  end

  it 'crea una orden, llama al customer_service y publica evento' do
    payload = {
      customer_id: customer_id,
      product_name: 'Zapatos',
      quantity: 2,
      price: 50.0,
      status: 'pending',
      total: 100.0
    }

    post '/orders', params: { order: payload }

    expect(response).to have_http_status(:created)
    json = JSON.parse(response.body)

    expect(json['order']['customer_id']).to eq(customer_id)
    expect(json['order']['product_name']).to eq('Zapatos')

    expect(json['customer']).to include('customer_name', 'address', 'orders_count')
  end
end
